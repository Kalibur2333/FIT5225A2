export const unique = (arr: string[]) => {
  return Array.from(new Set(arr));
};
