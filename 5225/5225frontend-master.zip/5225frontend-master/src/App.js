// src/App.js

import React from 'react';
import Router from './Router';

const App = () => (
  <div className="App">
    <Router />
  </div>
);

export default App;
