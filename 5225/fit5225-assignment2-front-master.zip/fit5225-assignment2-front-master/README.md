# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
After clone the repository into your local, use command
```bash
npm run dev
```
to run the code. The code should be able to run it self, however it's on port 4000 which is different from our default port.

* Configuration
Environment configurations are avaliable, in .env file. Use import.meta.env to import environment configurations to the code.

* Deployment instructions
The code support with Eslint and Prettier. Make sure run:
```bash
npm run lint:fix
```
before bush or build 


### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact
