// / <reference types="vite/client" />
interface ImportMetaEnv {
  VITE_APP_ANT: 'dev' | 'prod';
  readonly VITE_IMAGE_RECOGNITION_URL: string;
}
