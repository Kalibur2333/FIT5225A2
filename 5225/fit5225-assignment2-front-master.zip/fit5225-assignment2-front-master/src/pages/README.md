ALL pages should be in its own folder with a components folder
